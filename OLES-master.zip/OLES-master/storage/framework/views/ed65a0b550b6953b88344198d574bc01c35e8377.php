<?php $__env->startSection('style'); ?>
.add-question-btn{
    padding-bottom:20px;
}
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="panel panel-default row">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-12">
                                <h4>Questions List</h4>
                            </div>
                        </div>
                    </div>

                    
                    <div class="panel-body">

                        <div class="add-question-btn text-right">
                            <a href="<?php echo e(route('exams',$lesson->id)); ?>" class="btn btn-default btn-sm">All Exam</a>
                            <a href="<?php echo e(route('questions.create',$exam->id)); ?>" class="btn btn-default btn-sm">Add Question</a>
                        </div>

                        <table class="table table-stripped text-center">
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center">Question Name</th>
                                <th class="text-center">Option a</th>
                                <th class="text-center">Option b</th>
                                <th class="text-center">Option c</th>
                                <th class="text-center">Option c</th>
                                <th class="text-center">Action</th>
                            </tr>
                            <?php if(count($questions) > 0): ?>
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($question->id); ?></td>
                                        <td><?php echo e($question->name); ?></td>
                                        <td><?php echo e($question->opt_a); ?></td>
                                        <td><?php echo e($question->opt_b); ?></td>
                                        <td><?php echo e($question->opt_c); ?></td>
                                        <td><?php echo e($question->opt_c); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-success btn-sm">edit</a> |
                                            <a href="#" class="btn btn-danger btn-sm">delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7">No Question</td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Sidebar -->
            <div class="col-md-3">
                <?php echo $__env->make('teacher.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div><!--./row-->
    </div><!--./container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>