<div class="list-group">
    <li class="list-group-item list-group-item-default text-center active">Sidebar</li>
    <a href="<?php echo e(route('lessons')); ?>" class="list-group-item">
        <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span>
         My Lessons
    </a>
    <a href="<?php echo e(route('lessons.create')); ?>" class="list-group-item">
        <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span>
        Create Lesson
    </a>
    <a href="#" class="list-group-item">
        <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span>
        Poppular Lesson
    </a>
    <a href="#" class="list-group-item">
        <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span>
        History
    </a>
</div>
