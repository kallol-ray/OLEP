<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="panel panel-default">
                    <h4 class="panel-heading">My Lesson</h4>
                    
                    <div class="panel-body">
                        <?php if(count($lessons) > 0): ?>
                        <?php $__currentLoopData = $lessons->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk_lessons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <?php $__currentLoopData = $chunk_lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 thumbnail-wrapper" data-id='<?php echo e($lesson->id); ?>'>
                                <div class="thumbnail" style="display:block;">
                                    <div class="caption">
                                        <h3><?php echo e($lesson->lessons_title); ?></h3>
                                        <?php if( strlen($lesson->lessons_body) >= 150 ): ?>
                                        <p><?php echo e(substr($lesson->lessons_body,0,150)); ?></p>
                                        <?php else: ?>
                                        <p><?php echo e($lesson->lessons_body); ?></p>
                                        <?php endif; ?>
                                        <hr>
                                        <p class="price-details text-center">
                                            <?php if($lesson->lessons_price > 0.00): ?>
                                            $ <?php echo e($lesson->lessons_price); ?>

                                            <?php else: ?>
                                            Free
                                            <?php endif; ?>
                                        </p>
                                        <hr>
                                        <p class="lesson-action text-center" >
                                            <a title="view" href="<?php echo e(route('lessons.show',$lesson->id)); ?>" class="btn btn-default " role="button">
                                                <span  class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
                                            </a>
                                            <a title="edit" href="<?php echo e(route('lessons.edit',$lesson->id)); ?>" class="btn btn-default " role="button">
                                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            </a>
                                            <a onclick="setDeleteLessonURLWithId( <?php echo e($lesson->id); ?> )" title="delete" href="#" class="btn btn-default lesson-action__delete-link" role="button" data-toggle="modal" data-target="#myModal">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </a>
                                        </p>
                                        <hr>
                                        <p class="text-center">
                                            <a href="<?php echo e(route('exams',$lesson->id)); ?>" class="btn btn-default " role="button">
                                                Exams <i class="fa fa-arrow-circle-right" aria-hidden="true"></i>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        No Lesson
                        <?php endif; ?>
                        <a title="edit" href="<?php echo e(route('lessons.create')); ?>" class="btn btn-default " role="button">
                            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                        </a>
                    </div><!--./panel-body-->
                </div><!--./panel-->
            </div>
            <!-- Sidebar -->
            <div class="col-md-3">
               <?php echo $__env->make('teacher.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div><!--./row-->
    </div><!--./container-->

<!-- Modal Area -->
<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
          <h4>Are you sure?</h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-default modal-footer__yes-btn">
            <i class="fa fa-check" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">
            <i class="fa fa-times" aria-hidden="true"></i>
        </button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    var lessonId;
    var url;
    var token;
    function setDeleteLessonURLWithId(lessonId){
        url = '/lessons/' + parseInt( lessonId );
    }

    $('#myModal').on('shown.bs.modal');

    $(".modal-footer__yes-btn").click(function(){
        token = "<?php echo e(csrf_token()); ?>";
        $.ajax({
            url: url,
            type: "post",
            data: {_token: token, _method: "delete"}
        })
        .done(function(lessons){
            location.reload();
            $('#myModal').modal('hide');
        });

    });

<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>