<?php $__env->startSection('style'); ?>
    .add-exam-btn{
        padding-bottom: 20px;
    }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="panel panel-default row">
                    <h4 class="panel-heading">
                       Exam List
                   </h4>

                    
                    <div class="panel-body">
                            <?php if(count($exams) > 0): ?>
                                <?php $__currentLoopData = $exams->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <?php $__currentLoopData = $chunk_exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="thumbnail text-center">
                                                <h3><?php echo e($exam->name); ?> <span class="badge"><?php echo e($examObj->getCalculateTotalQuestions($exam->id)); ?></span></h3>
                                                <p>
                                                    <a title="view" href="<?php echo e(route('questions', ['lesson'=>$lesson->id,'exam'=>$exam->id])); ?>" class="btn btn-default " role="button">
                                                        <span  class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
                                                    </a>
                                                    <a title="edit" href="#" class="btn btn-default " role="button">
                                                        <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                                                    </a>
                                                    <a title="delete" href="#" class="btn btn-default " role="button">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                NO EXAM
                            <?php endif; ?>
                            <p class="">
                                <a href="<?php echo e(route('exams.create',$lesson->id)); ?>" class="btn btn-default">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </a>
                            </p>
                    </div>
                </div><!--./panel-->
            </div>
            <!-- Sidebar -->
            <div class="col-md-3">
                <?php echo $__env->make('teacher.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            
        </div><!--./row-->
    </div><!--./container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>