<?php $__env->startSection('style'); ?>
    .question__title{
        font-weight: bold;
    }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="panel panel-default row">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h2>
                                    <a href="<?php echo e(route('student.lessons.show',$lesson->id)); ?>"><?php echo e($lesson->lessons_title); ?></a>
                                </h2>
                                <p class="exam-info">
                                    Exam : <?php echo e($exam->name); ?>

                                    Total Questions : <span class="label label-primary"><?php echo e($total_questions); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="panel-body">
                        <?php if(count($questions) > 0): ?>
                            <form action="<?php echo e(route('result.store',['exam_id'=>$exam->id])); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                
                                <div class="row">
                                    <div class="col-md-11 col-md-offset-1">
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="question-wrapper">
                                                <div class="question__title"><?php echo e(++$counter); ?>. <?php echo e($question->name); ?></div>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="<?php echo e($question->id); ?>" value="opt_a"> <?php echo e($question->opt_a); ?>

                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="<?php echo e($question->id); ?>" value="opt_b"> <?php echo e($question->opt_b); ?>

                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="<?php echo e($question->id); ?>" value="opt_c"> <?php echo e($question->opt_c); ?>

                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="<?php echo e($question->id); ?>" value="opt_d"> <?php echo e($question->opt_d); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                

                                
                                <div class="row">
                                    <div class="col-md-12 text-right">
                                        <button type="submit" class="btn btn-primary text-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <p>No question</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-md-3">
                <?php echo $__env->make('student.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div><!--./row-->
    </div><!--./container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>