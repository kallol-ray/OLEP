<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Main Content -->
        <div class="col-md-9">
            <?php echo $__env->make('teacher.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="panel panel-default">
                <div class="panel-heading">Teacher</div>
                <div class="panel-body">
                    You are logged in!
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-3">
            <?php echo $__env->make('teacher.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    </div><!--./row-->
</div><!--./container-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>