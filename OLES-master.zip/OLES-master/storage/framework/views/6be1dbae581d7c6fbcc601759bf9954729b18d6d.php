<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-md-9">
                <div class="panel panel-default">
                    
                    <div class="panel-body">
                       <div class="col-md-12">
                           <h3>Dear <?php echo e(Auth::user()->first_name); ?></h3>
                           <p>
                               You got <span class="label label-danger"><?php echo e($user_mark); ?></span> mark in total <span class="label label-primary"><?php echo e($total_mark); ?></span> mark.
                           </p>
                           <strong>This is <span class="label label-info"><?php echo e($comment); ?></span></strong>
                       </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-md-3">
                <?php echo $__env->make('student.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div><!--./row-->
    </div><!--./container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>