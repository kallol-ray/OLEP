<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <!-- Content -->
            <div class="col-md-9">
                <div class="row student-search-box">
                    <div class="col-md-12">
                        <form class="student-search-form">
                            <div class="input-group">
                                <input type="text" class="form-control student-search-form__input" placeholder="Search for...">
                                <span class="input-group-btn">
                                     <button class="btn btn-default" type="submit">Go!</button>
                                </span>
                            </div>
                        </form>

                    </div>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <div class="student-search-form__result">
                            </div>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="thumbnail" style="background:#fff;">
                            <div class="caption">
                                <h3><?php echo e($lesson->lessons_title); ?></h3>
                                <hr>
                                <?php if(strlen($lesson->lessons_body) < 250 ): ?>
                                    <p>
                                        <?php echo e($lesson->lessons_body); ?>

                                        <a href="<?php echo e(route('student.lessons.show',$lesson->id)); ?>"><strong>read
                                                more..</strong></a>
                                    </p>
                                <?php else: ?>
                                    <p>
                                        <?php echo e(substr($lesson->lessons_body,0,250)); ?>

                                        <a href="<?php echo e(route('student.lessons.show',$lesson->id)); ?>"><strong>read
                                                more..</strong></a>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Sidebar-->
            <div class="col-md-3">
                <?php echo $__env->make('student.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div><!--/.row-->
    </div><!--/.container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".student-search-form").submit(function(event){
            event.preventDefault();
            var keyword = $(".student-search-form__input").val();
            var url = "<?php echo e(route('student.lessons.search')); ?>";
            var token = "<?php echo e(csrf_token()); ?>";
            var lesson_url = '/student/lessons/';
            if(keyword.length == 0){
                return $('.student-search-form__result p').hide();
            }
            $('.student-search-form__result a').remove();
            $.ajax({
                type: "get",
                url: url,
                data: {"q": keyword, _token: token },
                success: function (data) {
                    for(var i = 0;i<data.length;i++){
                        lesson_url = lesson_url+data[i].id;
                        $(".student-search-form__result").append("<p>Lessons <a href='"+lesson_url+"'>"+data[i].lessons_title+"</a></p>");
                    }
                },
                error: function(data){
                    alert("fail");
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>