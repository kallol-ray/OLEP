<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="panel panel-default">
                <h4 class="panel-heading">Create Exam</h4>

                <div class="panel-body">
                    <form action="<?php echo e(route('exams.store',$lesson->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="title">Name</label>
                            <input type="text" class="form-control" name="name">
                            <input type="hidden" value="<?php echo e($lesson->id); ?>" name="lesson_id">
                        </div>

                        <button type="submit" class="btn btn-default text-right">
                            <i class="fa fa-check-circle" aria-hidden="true"></i> Save
                        </button
                    </form>
                </div>
            </div>
         </div>
        <!-- Sidebar -->
        <div class="col-md-3">
            <?php echo $__env->make('teacher.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div><!--./row-->
</div><!--./container-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>