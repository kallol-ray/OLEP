<div class="list-group">
    <a href="{{ route('student.lessons') }}" class="list-group-item">
        <i class="fa fa-circle-o" aria-hidden="true"></i> Lessons
    </a>
    <a href="{{ route('student.lessons') }}" class="list-group-item">
        <i class="fa fa-circle-o" aria-hidden="true"></i>  Recent Lesson
    </a>
    <a href="#" class="list-group-item">
        <i class="fa fa-circle-o" aria-hidden="true"></i>  Poppular Lesson
    </a>
    <a href="#" class="list-group-item">
        <i class="fa fa-circle-o" aria-hidden="true"></i>  Bookmarks
    </a>
</div>
